<tr>
    <th><?php echo $row["IDNum"]?></th>
    <th><?php echo $row["IDName"]?></th>
    <th><?php echo $row["IDLocation"]?></th>
    <th><?php echo $row["IDFeedback"]?></th>
</tr>