<?php
    class DBConnection {
    public  function getDBConnection() {
        $con = mysqli_connect("localhost","root","","technicaltest");
        return $con;
    }
}
